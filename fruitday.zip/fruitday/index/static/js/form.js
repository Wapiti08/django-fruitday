/*网页加载后执行的操作*/
$(function(){
    /*为　form 绑定submit事件*/
    console.log($("#formReg"));
});